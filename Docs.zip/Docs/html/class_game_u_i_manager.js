var class_game_u_i_manager =
[
    [ "CloseExitMenu", "class_game_u_i_manager.html#a61616560cc57dcb7f72d192751c14b9f", null ],
    [ "ConfirmExit", "class_game_u_i_manager.html#a5490cb15003c43dbc35a2b2fc2999c20", null ],
    [ "DisplayStats", "class_game_u_i_manager.html#a540505f3e22b7a616e3dcb060066fc26", null ],
    [ "ExitToMenu", "class_game_u_i_manager.html#a6522ee6d697fd4dcedb7bcd1aba6aad6", null ],
    [ "Loose", "class_game_u_i_manager.html#a154bb42cab21b7ce333255debf1ad114", null ],
    [ "NextLvl", "class_game_u_i_manager.html#a04fb3b88e56ded5a11c9e63b1941affa", null ],
    [ "ReloadLvl", "class_game_u_i_manager.html#a93056d554f985ef53261edc71862d703", null ],
    [ "Win", "class_game_u_i_manager.html#ad67cb47c456f7327fe5d6f3b2e707df5", null ]
];