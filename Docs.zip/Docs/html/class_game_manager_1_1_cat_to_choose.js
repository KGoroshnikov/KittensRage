var class_game_manager_1_1_cat_to_choose =
[
    [ "catType", "class_game_manager_1_1_cat_to_choose.html#a6b522a55123330437990e38af1795516", null ],
    [ "obj", "class_game_manager_1_1_cat_to_choose.html#ac54ba529535252fdb1e3f9b42c79fe1e", null ],
    [ "prefThrow", "class_game_manager_1_1_cat_to_choose.html#a3fcc4648c8fb4de3b8aaa233f99b8181", null ],
    [ "vfx", "class_game_manager_1_1_cat_to_choose.html#adc2adf9b9f9088e6bd3e369ea7f34132", null ]
];