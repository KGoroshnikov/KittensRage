var _add_new_rat_event_8cs =
[
    [ "Gambling.Negative.AddNewRatEvent", "class_gambling_1_1_negative_1_1_add_new_rat_event.html", "class_gambling_1_1_negative_1_1_add_new_rat_event" ]
];