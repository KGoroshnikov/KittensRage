var _stupid_throwable_cat_8cs =
[
    [ "StupidThrowableCat", "class_stupid_throwable_cat.html", "class_stupid_throwable_cat" ]
];