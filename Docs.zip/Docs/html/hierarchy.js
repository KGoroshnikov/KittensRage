var hierarchy =
[
    [ "GameManager.CatToChoose", "class_game_manager_1_1_cat_to_choose.html", null ],
    [ "ImageManager.frame", "class_image_manager_1_1frame.html", null ],
    [ "Functions", "class_functions.html", null ],
    [ "IBeginDragHandler", null, [
      [ "WheelOfFortune", "class_wheel_of_fortune.html", null ]
    ] ],
    [ "IDragHandler", null, [
      [ "WheelOfFortune", "class_wheel_of_fortune.html", null ]
    ] ],
    [ "IEndDragHandler", null, [
      [ "WheelOfFortune", "class_wheel_of_fortune.html", null ]
    ] ],
    [ "Image", null, [
      [ "InverseMask", "class_inverse_mask.html", null ]
    ] ],
    [ "MonoBehaviour", null, [
      [ "AI.ArcherAI", "class_a_i_1_1_archer_a_i.html", null ],
      [ "AI.GigaCatAI", "class_a_i_1_1_giga_cat_a_i.html", null ],
      [ "CamMenu", "class_cam_menu.html", null ],
      [ "CameraController", "class_camera_controller.html", null ],
      [ "Explosive", "class_explosive.html", null ],
      [ "Gambling.GamblingManager", "class_gambling_1_1_gambling_manager.html", null ],
      [ "GameManager", "class_game_manager.html", null ],
      [ "GameUIManager", "class_game_u_i_manager.html", null ],
      [ "HealthManager", "class_health_manager.html", null ],
      [ "ImageManager", "class_image_manager.html", null ],
      [ "Math.BezierCurve", "class_math_1_1_bezier_curve.html", null ],
      [ "Math.BezierPoint", "class_math_1_1_bezier_point.html", null ],
      [ "Math.CatmullRomSpline", "class_math_1_1_catmull_rom_spline.html", null ],
      [ "Menu", "class_menu.html", null ],
      [ "MeteorSource", "class_meteor_source.html", null ],
      [ "MusicManager", "class_music_manager.html", null ],
      [ "Projectiles.Fireball", "class_projectiles_1_1_fireball.html", null ],
      [ "Projectiles.Projectile", "class_projectiles_1_1_projectile.html", null ],
      [ "SingleTwin", "class_single_twin.html", null ],
      [ "Slingshot", "class_slingshot.html", null ],
      [ "StarsManager", "class_stars_manager.html", null ],
      [ "ThrowableCat", "class_throwable_cat.html", [
        [ "MageThrowableCat", "class_mage_throwable_cat.html", null ],
        [ "StupidThrowableCat", "class_stupid_throwable_cat.html", null ],
        [ "TwinsThrowableCat", "class_twins_throwable_cat.html", null ]
      ] ],
      [ "VelocityDamageHandler", "class_velocity_damage_handler.html", null ],
      [ "WheelOfFortune", "class_wheel_of_fortune.html", null ]
    ] ],
    [ "ScriptableObject", null, [
      [ "Gambling.GamblingEvent", "class_gambling_1_1_gambling_event.html", [
        [ "Gambling.Negative.AddNewRatEvent", "class_gambling_1_1_negative_1_1_add_new_rat_event.html", null ],
        [ "Gambling.Negative.DecreaseExplosionPowerEvent", "class_gambling_1_1_negative_1_1_decrease_explosion_power_event.html", null ],
        [ "Gambling.Negative.DecreaseGigaCatHealthEvent", "class_gambling_1_1_negative_1_1_decrease_giga_cat_health_event.html", null ],
        [ "Gambling.Negative.RemoveRandomCatEvent", "class_gambling_1_1_negative_1_1_remove_random_cat_event.html", null ],
        [ "Gambling.Positive.AddRandomCatEvent", "class_gambling_1_1_positive_1_1_add_random_cat_event.html", null ],
        [ "Gambling.Positive.IncreaseExplosionPowerEvent", "class_gambling_1_1_positive_1_1_increase_explosion_power_event.html", null ],
        [ "Gambling.Positive.IncreaseGigaCatHealthEvent", "class_gambling_1_1_positive_1_1_increase_giga_cat_health_event.html", null ],
        [ "Gambling.Positive.MeteorRainEvent", "class_gambling_1_1_positive_1_1_meteor_rain_event.html", null ]
      ] ]
    ] ]
];