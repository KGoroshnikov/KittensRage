var _decrease_giga_cat_health_event_8cs =
[
    [ "Gambling.Negative.DecreaseGigaCatHealthEvent", "class_gambling_1_1_negative_1_1_decrease_giga_cat_health_event.html", "class_gambling_1_1_negative_1_1_decrease_giga_cat_health_event" ]
];