var searchData=
[
  ['activeimg_0',['activeImg',['../class_image_manager_1_1frame.html#ad804d553aa2cc99bf185a0de2a075106',1,'ImageManager::frame']]],
  ['amountofavaliabledamage_1',['AmountOfAvaliableDamage',['../class_throwable_cat.html#aaca5232d0f1b7b3ae46dc62440a372ff',1,'ThrowableCat']]]
];
