var searchData=
[
  ['gigacathealth_0',['gigaCatHealth',['../class_gambling_1_1_gambling_manager.html#a20af95b26adc562b9e8b1121be6e19b9',1,'Gambling.GamblingManager.gigaCatHealth'],['../class_wheel_of_fortune.html#a8381f83fe74c63a7c3619115cd8c4851',1,'WheelOfFortune.gigaCatHealth']]]
];
