var searchData=
[
  ['prefthrow_0',['prefThrow',['../class_game_manager_1_1_cat_to_choose.html#a3fcc4648c8fb4de3b8aaa233f99b8181',1,'GameManager::CatToChoose']]],
  ['puffeffect_1',['puffEffect',['../class_wheel_of_fortune.html#a4bc76cd1e400ef08ccc0a40ae813dce4',1,'WheelOfFortune']]]
];
