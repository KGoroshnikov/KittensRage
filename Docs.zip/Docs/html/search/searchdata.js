var indexSectionsWithContent =
{
  0: "abcdefghilmnopqrstuvw",
  1: "abcdefghimprstvw",
  2: "agmp",
  3: "abcdefghimprstvw",
  4: "acdefglmnoprstuw",
  5: "abcdfghilmnopqrstvw",
  6: "r",
  7: "c",
  8: "cdems",
  9: "chlmns"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "typedefs",
  7: "enums",
  8: "enumvalues",
  9: "properties"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Files",
  4: "Functions",
  5: "Variables",
  6: "Typedefs",
  7: "Enumerations",
  8: "Enumerator",
  9: "Properties"
};

