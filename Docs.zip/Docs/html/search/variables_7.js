var searchData=
[
  ['isstupid_0',['isStupid',['../class_slingshot.html#a357b9ba774c90cc1c84d7f01a31b78c6',1,'Slingshot']]]
];
