var searchData=
[
  ['damagemin_0',['damageMin',['../class_explosive.html#afe9b6977f9b97025876f44cf7c93010b',1,'Explosive']]],
  ['decelerationtime_1',['decelerationTime',['../class_wheel_of_fortune.html#a5811506625fd7c619d98b0cbb24af344',1,'WheelOfFortune']]]
];
