var searchData=
[
  ['canttakedamage_0',['canttakedamage',['../class_health_manager.html#a718308d2542addf73b742f50b6ed7482',1,'HealthManager']]],
  ['cattype_1',['catType',['../class_game_manager_1_1_cat_to_choose.html#a6b522a55123330437990e38af1795516',1,'GameManager::CatToChoose']]],
  ['currentframe_2',['currentFrame',['../class_image_manager.html#a6e94b4f0a2a03ebaa6084c26f3671bd0',1,'ImageManager']]]
];
