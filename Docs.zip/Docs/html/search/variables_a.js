var searchData=
[
  ['nextsprite_0',['nextSprite',['../class_image_manager_1_1frame.html#adef49655094cddf26b0084f8dc464aef',1,'ImageManager::frame']]]
];
