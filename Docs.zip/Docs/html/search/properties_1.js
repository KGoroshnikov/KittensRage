var searchData=
[
  ['health_0',['Health',['../class_health_manager.html#a14c172691ceadc97d5f436dc5c70f7fd',1,'HealthManager']]],
  ['healthmax_1',['HealthMax',['../class_health_manager.html#acae176a3066f8ea854a4378eac98f67c',1,'HealthManager']]]
];
