var searchData=
[
  ['doubles_0',['doubles',['../class_game_manager.html#a602cf4bb0f3256a3bc0a65844a928f69a2155d8af2e7bb07fa61c84c2e15c72b6',1,'GameManager']]]
];
