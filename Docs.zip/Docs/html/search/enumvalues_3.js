var searchData=
[
  ['magician_0',['magician',['../class_game_manager.html#a602cf4bb0f3256a3bc0a65844a928f69afad4bbca84eb05c90b82a9fb0158ac76',1,'GameManager']]]
];
