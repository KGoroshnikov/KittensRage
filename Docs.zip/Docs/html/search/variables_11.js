var searchData=
[
  ['vfx_0',['vfx',['../class_game_manager_1_1_cat_to_choose.html#adc2adf9b9f9088e6bd3e369ea7f34132',1,'GameManager::CatToChoose']]],
  ['vfxpuff_1',['vfxPuff',['../class_throwable_cat.html#a6db21295876c0d7ea2e3a3f82b53821a',1,'ThrowableCat']]]
];
