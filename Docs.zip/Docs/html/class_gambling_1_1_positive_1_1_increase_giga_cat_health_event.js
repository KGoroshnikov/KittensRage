var class_gambling_1_1_positive_1_1_increase_giga_cat_health_event =
[
    [ "Execute", "class_gambling_1_1_positive_1_1_increase_giga_cat_health_event.html#a08204f5f13bcb7ebe80c8af513fc6766", null ],
    [ "Name", "class_gambling_1_1_positive_1_1_increase_giga_cat_health_event.html#a20dbbe441326b000eceaa72f46624af2", null ]
];