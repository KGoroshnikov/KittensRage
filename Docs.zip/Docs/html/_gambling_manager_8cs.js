var _gambling_manager_8cs =
[
    [ "Gambling.GamblingManager", "class_gambling_1_1_gambling_manager.html", "class_gambling_1_1_gambling_manager" ]
];