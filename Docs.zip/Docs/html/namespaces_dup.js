var namespaces_dup =
[
    [ "AI", "namespace_a_i.html", "namespace_a_i" ],
    [ "Gambling", "namespace_gambling.html", "namespace_gambling" ],
    [ "Math", "namespace_math.html", "namespace_math" ],
    [ "Projectiles", "namespace_projectiles.html", "namespace_projectiles" ]
];