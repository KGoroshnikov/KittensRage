var _game_manager_8cs =
[
    [ "GameManager", "class_game_manager.html", "class_game_manager" ],
    [ "GameManager.CatToChoose", "class_game_manager_1_1_cat_to_choose.html", "class_game_manager_1_1_cat_to_choose" ]
];