var namespace_a_i =
[
    [ "ArcherAI", "class_a_i_1_1_archer_a_i.html", "class_a_i_1_1_archer_a_i" ],
    [ "GigaCatAI", "class_a_i_1_1_giga_cat_a_i.html", "class_a_i_1_1_giga_cat_a_i" ]
];