var class_image_manager_1_1frame =
[
    [ "activeImg", "class_image_manager_1_1frame.html#ad804d553aa2cc99bf185a0de2a075106", null ],
    [ "fadeTime", "class_image_manager_1_1frame.html#aa3b9975b91f466eb9d78c57c28beb2ea", null ],
    [ "maskOffset", "class_image_manager_1_1frame.html#a170aca3e7ace4a15223003584b388be9", null ],
    [ "material", "class_image_manager_1_1frame.html#a852f3987bbb1250cf12779655ba24992", null ],
    [ "maxScaleAdd", "class_image_manager_1_1frame.html#ad3d4f2eed3a2b618eda3ecedfc811a8a", null ],
    [ "nextSprite", "class_image_manager_1_1frame.html#adef49655094cddf26b0084f8dc464aef", null ],
    [ "targetScale", "class_image_manager_1_1frame.html#ab6a6a8648c9c989dbb67a371fb94774e", null ],
    [ "timeImg", "class_image_manager_1_1frame.html#a1b79b3a3cba8f5cfac95a7eaa6cc7d22", null ],
    [ "timeMask", "class_image_manager_1_1frame.html#a79ae63f70026f3dc5b81da504743e49b", null ]
];