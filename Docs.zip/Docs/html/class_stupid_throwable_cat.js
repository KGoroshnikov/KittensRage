var class_stupid_throwable_cat =
[
    [ "Launch", "class_stupid_throwable_cat.html#ae06d8f9905973e29a9dd7da5bbaa3060", null ],
    [ "OnCollisionEnter", "class_stupid_throwable_cat.html#a92007a7bcf462d952b2b44dfa33a6498", null ]
];