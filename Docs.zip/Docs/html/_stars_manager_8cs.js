var _stars_manager_8cs =
[
    [ "StarsManager", "class_stars_manager.html", "class_stars_manager" ]
];