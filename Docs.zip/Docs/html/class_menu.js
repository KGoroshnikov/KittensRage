var class_menu =
[
    [ "CloseExitMenu", "class_menu.html#a980361847aeed1cbb2b95ea4538c64ae", null ],
    [ "ConfirmExit", "class_menu.html#aef2471f2b958e1a2b6d4895755600322", null ],
    [ "ExitApp", "class_menu.html#ad61313c822998f2311e579b7add22066", null ],
    [ "MainSoundBtn", "class_menu.html#aea111e3c75d98458d0d24c709c31ef1f", null ],
    [ "MusicBtn", "class_menu.html#afc6c3a2b5b659884cab9d1376e3bff67", null ],
    [ "PlayBtnSound", "class_menu.html#abef5508e6d5ad885fecfd26bb37a1c73", null ],
    [ "PlayButton", "class_menu.html#a76f0c00b753ee9c1c841fc86d932aad1", null ],
    [ "PlayCancelSound", "class_menu.html#a9d23a3414240f4988f6109f065a2c529", null ],
    [ "PlayPlaySound", "class_menu.html#a51541d57cbdcf465500ce3e0b9897344", null ],
    [ "TurnBloom", "class_menu.html#a6f74decd623331d52194fc33a4096846", null ],
    [ "WatchTrailerAgain", "class_menu.html#ad0c5dcfbc2e51c7d56952069e367a889", null ]
];