var class_gambling_1_1_negative_1_1_add_new_rat_event =
[
    [ "Execute", "class_gambling_1_1_negative_1_1_add_new_rat_event.html#ad684117006dfc196bb4cfcd4ac90ca48", null ],
    [ "Name", "class_gambling_1_1_negative_1_1_add_new_rat_event.html#a1a8fc7d826b6234485738fe075d2a99f", null ]
];