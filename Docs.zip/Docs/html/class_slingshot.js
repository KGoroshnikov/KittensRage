var class_slingshot =
[
    [ "ActivateMe", "class_slingshot.html#a9a9f48f757c8d51024c7dc1d6a2126e8", null ],
    [ "AddRandomCat", "class_slingshot.html#a0d5afa367567da125750274795a95331", null ],
    [ "GetCats", "class_slingshot.html#a699587b1faff28a5dcc4e005eb310220", null ],
    [ "RemoveCat", "class_slingshot.html#a702989d8f456d2397d2459927997df46", null ],
    [ "heightJump", "class_slingshot.html#ab370e01f34fbf5154d070ced43446d84", null ],
    [ "isStupid", "class_slingshot.html#a357b9ba774c90cc1c84d7f01a31b78c6", null ],
    [ "launchForceMultiplier", "class_slingshot.html#a27c0f77d8a9be1ccca1c9ecf9b29f934", null ],
    [ "maxAngle", "class_slingshot.html#ae141aafe205b3ef425c3a93796c5cd21", null ],
    [ "maxStretch", "class_slingshot.html#a4b2da38a7e0523ccda92d848807e4623", null ],
    [ "minAngle", "class_slingshot.html#a6a50ef3845a343a0676dcd00d227d5e5", null ],
    [ "queue", "class_slingshot.html#a1e5e19a35620a4133e44362ff26fce3a", null ],
    [ "slingOrigin", "class_slingshot.html#a9cbfbcc50cff9a1dc7fa58bc1f4c4845", null ],
    [ "speedJumpIn", "class_slingshot.html#a85ba5ed56359ffb26de0a10ce65a3290", null ],
    [ "stupidForceMul", "class_slingshot.html#a06196f8f1af8d5ff23a90871ee78f23d", null ],
    [ "stupidTPPos", "class_slingshot.html#a4251d2ec51c5be0a1a0e76741eb89a53", null ],
    [ "trajectoryLine", "class_slingshot.html#ae51e77b6b6498ba12360eebaa7706bb5", null ],
    [ "trajectoryPointsCount", "class_slingshot.html#ab6a40595c2bbda5feb40416328c8af15", null ]
];