var class_image_manager =
[
    [ "frame", "class_image_manager_1_1frame.html", "class_image_manager_1_1frame" ],
    [ "currentFrame", "class_image_manager.html#a6e94b4f0a2a03ebaa6084c26f3671bd0", null ]
];