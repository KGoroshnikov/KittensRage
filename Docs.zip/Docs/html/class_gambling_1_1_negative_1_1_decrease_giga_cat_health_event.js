var class_gambling_1_1_negative_1_1_decrease_giga_cat_health_event =
[
    [ "Execute", "class_gambling_1_1_negative_1_1_decrease_giga_cat_health_event.html#a7c8eb1d588d8c4f2c4d089ee9cfd21f9", null ],
    [ "Name", "class_gambling_1_1_negative_1_1_decrease_giga_cat_health_event.html#a064c34dfa0ec16e431e8f31e6b763275", null ]
];