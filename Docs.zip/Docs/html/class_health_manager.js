var class_health_manager =
[
    [ "ChangeHealth", "class_health_manager.html#a2708da1bfe1a722faf71055d18c6caf4", null ],
    [ "ChangeMaxHealth", "class_health_manager.html#af8b51c01262ceacd90f6cf8d8cf4a252", null ],
    [ "DestroyThis", "class_health_manager.html#acac85d8e5dde436b73b44a7a61eab4a2", null ],
    [ "canttakedamage", "class_health_manager.html#a718308d2542addf73b742f50b6ed7482", null ],
    [ "Health", "class_health_manager.html#a14c172691ceadc97d5f436dc5c70f7fd", null ],
    [ "HealthMax", "class_health_manager.html#acae176a3066f8ea854a4378eac98f67c", null ]
];