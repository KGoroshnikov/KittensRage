var class_gambling_1_1_negative_1_1_remove_random_cat_event =
[
    [ "Execute", "class_gambling_1_1_negative_1_1_remove_random_cat_event.html#a00d114df7960785042d8681c3b32c9ad", null ],
    [ "Name", "class_gambling_1_1_negative_1_1_remove_random_cat_event.html#a0471bb333c1e7c2aa7beeb1a973a04fb", null ]
];