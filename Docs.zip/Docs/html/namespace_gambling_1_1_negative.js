var namespace_gambling_1_1_negative =
[
    [ "AddNewRatEvent", "class_gambling_1_1_negative_1_1_add_new_rat_event.html", "class_gambling_1_1_negative_1_1_add_new_rat_event" ],
    [ "DecreaseExplosionPowerEvent", "class_gambling_1_1_negative_1_1_decrease_explosion_power_event.html", "class_gambling_1_1_negative_1_1_decrease_explosion_power_event" ],
    [ "DecreaseGigaCatHealthEvent", "class_gambling_1_1_negative_1_1_decrease_giga_cat_health_event.html", "class_gambling_1_1_negative_1_1_decrease_giga_cat_health_event" ],
    [ "RemoveRandomCatEvent", "class_gambling_1_1_negative_1_1_remove_random_cat_event.html", "class_gambling_1_1_negative_1_1_remove_random_cat_event" ]
];