var class_wheel_of_fortune =
[
    [ "ActivateMe", "class_wheel_of_fortune.html#a02fd6fbfe91357c78e82bd147a76fdc6", null ],
    [ "DisableMe", "class_wheel_of_fortune.html#a62e04d84f443a659307aa28995df5a9e", null ],
    [ "OnBeginDrag", "class_wheel_of_fortune.html#ac944399a9bff2db6bb6ebcd41a8f49c6", null ],
    [ "OnDrag", "class_wheel_of_fortune.html#a93d98fdd57d206824353fa6c331c58d5", null ],
    [ "OnEndDrag", "class_wheel_of_fortune.html#aceb8cb4d257aaf0a2913f1312e99d3c0", null ],
    [ "decelerationTime", "class_wheel_of_fortune.html#a5811506625fd7c619d98b0cbb24af344", null ],
    [ "fireballPref", "class_wheel_of_fortune.html#ad1d4aa3e2cf395da7deb35f967901499", null ],
    [ "gigaCatHealth", "class_wheel_of_fortune.html#a8381f83fe74c63a7c3619115cd8c4851", null ],
    [ "mainParent", "class_wheel_of_fortune.html#addd8db145a5b44bfd79a4af3ae7b46b6", null ],
    [ "maxSpeed", "class_wheel_of_fortune.html#a56043fd56b7169c51c06872aad6116b7", null ],
    [ "meteorSources", "class_wheel_of_fortune.html#a376caef2d96ff173715248d2f31bfe20", null ],
    [ "minSpeed", "class_wheel_of_fortune.html#ae7e477ed8ef0565e88e83b5532ce3e81", null ],
    [ "puffEffect", "class_wheel_of_fortune.html#a4bc76cd1e400ef08ccc0a40ae813dce4", null ],
    [ "ratPref", "class_wheel_of_fortune.html#ae2466889031560959f1e7bd686748a95", null ],
    [ "slingshot", "class_wheel_of_fortune.html#a2331d94ed88945c50bba6f09a831d8d2", null ],
    [ "spawnPoints", "class_wheel_of_fortune.html#a326e6bbf312e8c9ee0ec8ec9eb35a3e3", null ],
    [ "wheel", "class_wheel_of_fortune.html#aa0640ce835e854f4ba50f9e53bbbd28d", null ]
];