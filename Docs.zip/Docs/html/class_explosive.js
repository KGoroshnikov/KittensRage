var class_explosive =
[
    [ "Explode", "class_explosive.html#a02d2586aebe49fa2f033fcc8836dacdb", null ],
    [ "damageMin", "class_explosive.html#afe9b6977f9b97025876f44cf7c93010b", null ],
    [ "force", "class_explosive.html#ae1bf277eb380effdae63ac6d93e41dcd", null ],
    [ "radiusFactor", "class_explosive.html#a5f0b485984e5b899db2d21f92d53269f", null ]
];