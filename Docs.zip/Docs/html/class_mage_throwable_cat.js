var class_mage_throwable_cat =
[
    [ "Launch", "class_mage_throwable_cat.html#ab1c7e10281f3f0cdd25c2c4975fe7056", null ],
    [ "Start", "class_mage_throwable_cat.html#af6c42c43582337b666b049661cac721c", null ]
];