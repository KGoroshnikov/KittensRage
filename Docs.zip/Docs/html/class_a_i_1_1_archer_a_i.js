var class_a_i_1_1_archer_a_i =
[
    [ "AllowAttack", "class_a_i_1_1_archer_a_i.html#a120d9195ed0a9f6630d8c05031bdb805", null ],
    [ "Attack", "class_a_i_1_1_archer_a_i.html#a391ce028173c017aa75d82c71eb2bfb1", null ]
];