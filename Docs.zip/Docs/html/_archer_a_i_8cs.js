var _archer_a_i_8cs =
[
    [ "AI.ArcherAI", "class_a_i_1_1_archer_a_i.html", "class_a_i_1_1_archer_a_i" ],
    [ "Random", "_archer_a_i_8cs.html#a832e8f52fca5a678819ec96269dcb532", null ]
];