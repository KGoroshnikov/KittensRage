var class_stars_manager =
[
    [ "AddToQueue", "class_stars_manager.html#a4991fe3984424ed361740712fbfc26b9", null ],
    [ "getStars", "class_stars_manager.html#a02d43b25d1e5ce7a7598358902f20534", null ]
];