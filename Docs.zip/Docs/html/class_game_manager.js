var class_game_manager =
[
    [ "CatToChoose", "class_game_manager_1_1_cat_to_choose.html", "class_game_manager_1_1_cat_to_choose" ],
    [ "CatTypes", "class_game_manager.html#a602cf4bb0f3256a3bc0a65844a928f69", [
      [ "err", "class_game_manager.html#a602cf4bb0f3256a3bc0a65844a928f69a56bd7107802ebe56c6918992f0608ec6", null ],
      [ "cat", "class_game_manager.html#a602cf4bb0f3256a3bc0a65844a928f69ad077f244def8a70e5ea758bd8352fcd8", null ],
      [ "magician", "class_game_manager.html#a602cf4bb0f3256a3bc0a65844a928f69afad4bbca84eb05c90b82a9fb0158ac76", null ],
      [ "doubles", "class_game_manager.html#a602cf4bb0f3256a3bc0a65844a928f69a2155d8af2e7bb07fa61c84c2e15c72b6", null ],
      [ "stupid", "class_game_manager.html#a602cf4bb0f3256a3bc0a65844a928f69afc0586aca6e42cffade83252446d0613", null ]
    ] ],
    [ "ActivateWheel", "class_game_manager.html#a39e2894cdf069cd47229d5806bef1117", null ],
    [ "CloseWheel", "class_game_manager.html#aad96f1ecc3bdb539674de4875a99a9f3", null ],
    [ "GetBackFromWheel", "class_game_manager.html#a57a35d6bea3449be0de0f001bd451976", null ],
    [ "getGigaHealth", "class_game_manager.html#a43b3ff0c254868e2a302d7536394f04c", null ],
    [ "getMainParent", "class_game_manager.html#a4ffe8d28cc4570c1b6516be9fc7caef5", null ],
    [ "StartTimer", "class_game_manager.html#ac1cedb44945659cac6ec07b4483886b3", null ],
    [ "StopTimer", "class_game_manager.html#a5f4ba28059042a6cbe97690c161bfd5e", null ],
    [ "TurnMusicOff", "class_game_manager.html#a8e1c04f1db469a84dc1992b4a17dc502", null ]
];