var annotated_dup =
[
    [ "AI", "namespace_a_i.html", [
      [ "ArcherAI", "class_a_i_1_1_archer_a_i.html", "class_a_i_1_1_archer_a_i" ],
      [ "GigaCatAI", "class_a_i_1_1_giga_cat_a_i.html", "class_a_i_1_1_giga_cat_a_i" ]
    ] ],
    [ "Gambling", "namespace_gambling.html", [
      [ "Negative", "namespace_gambling_1_1_negative.html", [
        [ "AddNewRatEvent", "class_gambling_1_1_negative_1_1_add_new_rat_event.html", "class_gambling_1_1_negative_1_1_add_new_rat_event" ],
        [ "DecreaseExplosionPowerEvent", "class_gambling_1_1_negative_1_1_decrease_explosion_power_event.html", "class_gambling_1_1_negative_1_1_decrease_explosion_power_event" ],
        [ "DecreaseGigaCatHealthEvent", "class_gambling_1_1_negative_1_1_decrease_giga_cat_health_event.html", "class_gambling_1_1_negative_1_1_decrease_giga_cat_health_event" ],
        [ "RemoveRandomCatEvent", "class_gambling_1_1_negative_1_1_remove_random_cat_event.html", "class_gambling_1_1_negative_1_1_remove_random_cat_event" ]
      ] ],
      [ "Positive", "namespace_gambling_1_1_positive.html", [
        [ "AddRandomCatEvent", "class_gambling_1_1_positive_1_1_add_random_cat_event.html", "class_gambling_1_1_positive_1_1_add_random_cat_event" ],
        [ "IncreaseExplosionPowerEvent", "class_gambling_1_1_positive_1_1_increase_explosion_power_event.html", "class_gambling_1_1_positive_1_1_increase_explosion_power_event" ],
        [ "IncreaseGigaCatHealthEvent", "class_gambling_1_1_positive_1_1_increase_giga_cat_health_event.html", "class_gambling_1_1_positive_1_1_increase_giga_cat_health_event" ],
        [ "MeteorRainEvent", "class_gambling_1_1_positive_1_1_meteor_rain_event.html", "class_gambling_1_1_positive_1_1_meteor_rain_event" ]
      ] ],
      [ "GamblingEvent", "class_gambling_1_1_gambling_event.html", "class_gambling_1_1_gambling_event" ],
      [ "GamblingManager", "class_gambling_1_1_gambling_manager.html", "class_gambling_1_1_gambling_manager" ]
    ] ],
    [ "Math", "namespace_math.html", [
      [ "BezierCurve", "class_math_1_1_bezier_curve.html", "class_math_1_1_bezier_curve" ],
      [ "BezierPoint", "class_math_1_1_bezier_point.html", "class_math_1_1_bezier_point" ],
      [ "CatmullRomSpline", "class_math_1_1_catmull_rom_spline.html", "class_math_1_1_catmull_rom_spline" ]
    ] ],
    [ "Projectiles", "namespace_projectiles.html", [
      [ "Fireball", "class_projectiles_1_1_fireball.html", "class_projectiles_1_1_fireball" ],
      [ "Projectile", "class_projectiles_1_1_projectile.html", null ]
    ] ],
    [ "CameraController", "class_camera_controller.html", "class_camera_controller" ],
    [ "CamMenu", "class_cam_menu.html", null ],
    [ "Explosive", "class_explosive.html", "class_explosive" ],
    [ "Functions", "class_functions.html", null ],
    [ "GameManager", "class_game_manager.html", "class_game_manager" ],
    [ "GameUIManager", "class_game_u_i_manager.html", "class_game_u_i_manager" ],
    [ "HealthManager", "class_health_manager.html", "class_health_manager" ],
    [ "ImageManager", "class_image_manager.html", "class_image_manager" ],
    [ "InverseMask", "class_inverse_mask.html", "class_inverse_mask" ],
    [ "MageThrowableCat", "class_mage_throwable_cat.html", "class_mage_throwable_cat" ],
    [ "Menu", "class_menu.html", "class_menu" ],
    [ "MeteorSource", "class_meteor_source.html", "class_meteor_source" ],
    [ "MusicManager", "class_music_manager.html", "class_music_manager" ],
    [ "SingleTwin", "class_single_twin.html", null ],
    [ "Slingshot", "class_slingshot.html", "class_slingshot" ],
    [ "StarsManager", "class_stars_manager.html", "class_stars_manager" ],
    [ "StupidThrowableCat", "class_stupid_throwable_cat.html", "class_stupid_throwable_cat" ],
    [ "ThrowableCat", "class_throwable_cat.html", "class_throwable_cat" ],
    [ "TwinsThrowableCat", "class_twins_throwable_cat.html", "class_twins_throwable_cat" ],
    [ "VelocityDamageHandler", "class_velocity_damage_handler.html", null ],
    [ "WheelOfFortune", "class_wheel_of_fortune.html", "class_wheel_of_fortune" ]
];