var namespace_gambling =
[
    [ "Negative", "namespace_gambling_1_1_negative.html", "namespace_gambling_1_1_negative" ],
    [ "Positive", "namespace_gambling_1_1_positive.html", "namespace_gambling_1_1_positive" ],
    [ "GamblingEvent", "class_gambling_1_1_gambling_event.html", "class_gambling_1_1_gambling_event" ],
    [ "GamblingManager", "class_gambling_1_1_gambling_manager.html", "class_gambling_1_1_gambling_manager" ]
];